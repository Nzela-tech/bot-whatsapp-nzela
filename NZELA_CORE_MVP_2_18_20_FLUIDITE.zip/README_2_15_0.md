# NZELA CORE MVP 2.15.0 — Identité de boutique persistante

## Fonctionnement

Dans l’espace administrateur :
- le logo rond et le nom de la boutique restent visibles dans le monde administrateur ;
- le bloc est placé en haut avec un style flottant/sticky ;
- cliquer sur le logo ou le nom ouvre une carte ;
- la carte affiche le logo, le nom, le slogan, le contact et le secteur lorsqu’ils existent ;
- cliquer à nouveau sur le bloc ou sur la croix referme la carte ;
- sans logo, l’espace reste propre et le nom est conservé.

## Fichiers modifiés

- `web/admin.html`
- `web/assets/admin.js`
- `web/assets/admin.css`
- `VERSION`
