# NZELA CORE — MVP fonctionnel 1.9.1

Cette version est la base MVP fonctionnelle du cas d'utilisation **Restaurant**.

## Parcours fonctionnel

1. Le serveur démarre avec `start_nzela.bat`.
2. Le client ouvre l'espace restaurant.
3. Le client choisit un ou plusieurs articles et règle les quantités.
4. Il renseigne son nom et son téléphone.
5. La commande est enregistrée dans SQLite et reçoit un numéro de file.
6. L'espace entreprise récupère automatiquement la commande.
7. L'entreprise fait évoluer le statut : `pending` → `preparing` → `ready` → `completed` (ou `cancelled`).
8. Le client peut retrouver ses commandes récentes dans **Historique** sur le même appareil.
9. Chaque création et chaque changement de statut sont inscrits dans le journal `events`.

## Lancement

```text
start_nzela.bat
```

Puis ouvrir :

```text
http://127.0.0.1:8787
```

Depuis un autre appareil du même réseau local, utiliser l'adresse LAN affichée par le serveur, par exemple `http://192.168.x.x:8787`.

## Test fonctionnel

Le serveur doit être lancé avant le test :

```text
start_nzela.bat
```

Dans un deuxième terminal :

```text
py -3 tests\smoke_test.py
py -3 tests\mvp_test.py
```

Le deuxième test crée réellement une commande, vérifie sa persistance et fait évoluer son statut.

## Données

La base SQLite se trouve dans :

```text
data\nzela.db
```

Pour repartir sur une démonstration vierge, arrêter le serveur puis supprimer `data\nzela.db`.

## Correction importante de cette version

Les articles du restaurant utilisent maintenant correctement leur `operation_kind` (`menu_item`). La création de commande ne confond plus l'identifiant produit avec la définition de l'opération du catalogue.

Le stock disponible est également vérifié et décrémenté lors de l'enregistrement d'une commande.
