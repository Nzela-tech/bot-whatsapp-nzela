# NZELA 2.18.1

- Barre principale client et admin réellement fixe en haut.
- Le scale ne déplace plus la barre.
- L’espace client charge et affiche maintenant les informations de la boutique depuis `/api/config`.
- Le point flottant reste superposé sans déplacer la mise en page.
