@echo off
py --version
if errorlevel 1 (echo Le lanceur py n'est pas disponible.) else (echo OK - py est disponible.)
pause
