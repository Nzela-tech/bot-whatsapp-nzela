
function updateShopIdentityDock(identity){
  const data = identity || {};
  const name = data.name || 'Ma boutique';
  const logo = data.logo || data.logo_data || data.image_data || '';
  const slogan = data.slogan || '';
  const contact = data.contact || data.phone || data.telephone || '—';
  const sector = data.sector || data.activity || '—';
  const setText = (id, value) => { const el = document.getElementById(id); if(el) el.textContent = value || '—'; };
  setText('shopDockName', name);
  setText('shopCardName', name);
  setText('shopCardSlogan', slogan);
  setText('shopCardContact', contact);
  setText('shopCardSector', sector);
  ['shopDockLogo','shopCardLogo'].forEach(id => {
    const img = document.getElementById(id);
    if(!img) return;
    if(logo){ img.src = logo; img.hidden = false; }
    else { img.removeAttribute('src'); img.hidden = true; }
  });
}
function bindShopIdentityDock(){
  const dock = document.getElementById('shopIdentityDock');
  const card = document.getElementById('shopIdentityCard');
  const close = document.getElementById('closeShopIdentityCard');
  if(!dock || !card || dock.dataset.bound) return;
  dock.dataset.bound = '1';
  const open = () => { card.hidden = false; dock.setAttribute('aria-expanded','true'); card.scrollIntoView({behavior:'smooth', block:'nearest'}); };
  const shut = () => { card.hidden = true; dock.setAttribute('aria-expanded','false'); };
  dock.addEventListener('click', () => card.hidden ? open() : shut());
  close?.addEventListener('click', shut);
}

const $=s=>document.querySelector(s);
const THEME_KEY='nzela_theme_mode';
const THEME_SCALE_KEY='nzela_theme_scale';
function applyThemeScale(value){const scale=Math.max(0,Math.min(100,Number(value)||0));document.body.style.setProperty('--theme-scale',scale+'%');const el=$('#themeScale'),label=$('#themeScaleLabel');if(el)el.value=String(scale);if(label)label.textContent=String(scale)+'%';try{localStorage.setItem(THEME_SCALE_KEY,String(scale))}catch(e){}}
function applyTheme(mode,scale){document.body.classList.toggle('light',mode==='light');document.body.classList.toggle('admin-dark',mode!=='light');try{localStorage.setItem(THEME_KEY,mode)}catch(e){}applyThemeScale(scale ?? Number(localStorage.getItem(THEME_SCALE_KEY) ?? 50));const button=$('#themeToggle');if(button){button.textContent=mode==='light'?'☾':'☼';button.title=mode==='light'?'Passer en mode sombre':'Passer en mode clair';button.setAttribute('aria-label',button.title)}}
function theme(){const next=document.body.classList.contains('light')?'dark':'light';applyTheme(next)}
function initAdminTheme(){let mode='dark',scale=50;try{mode=localStorage.getItem(THEME_KEY)==='light'?'light':'dark';scale=Number(localStorage.getItem(THEME_SCALE_KEY) ?? 50)}catch(e){}applyTheme(mode,scale);$('#themeToggle')?.addEventListener('click',theme);$('#themeScale')?.addEventListener('input',e=>applyThemeScale(e.target.value));}
initAdminTheme();
async function api(p,o={}){let r=await fetch(p,{cache:'no-store',...o,headers:{'Content-Type':'application/json',...(o.headers||{})}}),d=await r.json();if(!r.ok)throw Error(d.error||'Erreur');return d}
function opSpec(kind){return catalog.operations.find(o=>o.kind===kind)||{name:kind}}
function kindLabel(kind){return opSpec(kind).name}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function detailsText(it){const d=it.details||{};let pairs=[];for(const [k,v] of Object.entries(d)){if(k==='operation'||!v)continue;const labels={phone:'Numéro de téléphone',recipient_phone:'Bénéficiaire',recipient_name:'Nom du destinataire',operator:'Opérateur',amount:'Montant',target:'Destination',beneficiary_id:'Identifiant'};pairs.push(`${labels[k]||k}: ${esc(v)}`)}return pairs.join(' • ')}
function requestCard(x){const ops=(x.items||[]).map(it=>`<div class="requestOperation"><b>${esc(it.name)}</b><span>${esc(kindLabel(it.kind)||'Article')}</span><small>${it.quantity>1?`Quantité: ${it.quantity} • `:''}${detailsText(it)}</small></div>`).join('');return `<div class="listItem requestCard"><div><b>#${String(x.queue_number).padStart(3,'0')} — ${esc(x.customer_name)}</b><div class="mut">${esc(x.customer_phone||'')} • ${x.items?.length||0} article(s)</div><div class="requestOperations">${ops}</div></div><select onchange="setStatus('${x.id}',this.value)"><option ${x.status==='pending'?'selected':''}>pending</option><option ${x.status==='preparing'?'selected':''}>preparing</option><option ${x.status==='ready'?'selected':''}>ready</option><option ${x.status==='completed'?'selected':''}>completed</option><option ${x.status==='cancelled'?'selected':''}>cancelled</option></select></div>`}
function renderRequests(){const q=($('#requestSearch')?.value||'').toLowerCase();const items=allRequests.filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q));$('#requests').innerHTML=items.map(requestCard).join('')||'<p class="mut">Aucune demande.</p>';$('#requestsPreview').innerHTML=allRequests.slice(0,6).map(requestCard).join('')||'<p class="mut">Aucune demande.</p>'}
async function loadCategories(selected=''){
  const r=await api('/api/categories');
  categoriesCache=r.items||[];
  const form=$('#pcategory'), filter=$('#productCategoryFilter');
  if(form){
    const current=selected||form.value;
    form.innerHTML=categoriesCache.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('')+`<option value="__new__">＋ Ajouter une catégorie…</option>`;
    if(current && categoriesCache.some(c=>c.name===current)) form.value=current; else if(categoriesCache.length) form.value=categoriesCache[0].name;
  }
  if(filter){
    const current=productCategoryFilter||filter.value;
    filter.innerHTML='<option value="">Toutes les catégories</option>'+categoriesCache.map(c=>`<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
    filter.value=categoriesCache.some(c=>c.name===current)?current:'';
  }
}
function renderProducts(){
  const q=(productCategoryFilter||'').toLocaleLowerCase();
  const items=productsCache.filter(x=>!q||String(x.category||'').toLocaleLowerCase()===q);
  $('#productList').innerHTML=items.map(x=>`<div class="listItem adminObject"><div><b>${esc(x.name)}</b><div class="mut">${esc(x.category)} • ${Number(x.price).toLocaleString('fr-FR')} FCFA • Stock: ${x.stock}</div></div><div><button onclick="editProduct('${x.id}')">Modifier</button> <button onclick="toggleProduct('${x.id}',${!x.available})">${x.available?'Masquer':'Afficher'}</button> <button onclick="deleteProduct('${x.id}')">Supprimer</button></div></div>`).join('')||'<p class="mut">Aucun produit dans cette catégorie.</p>';
}
async function refresh(){try{const r=await api('/api/requests');allRequests=r.items||[];renderRequests();const [cfg,s,p,h,a,health,cats]=await Promise.all([api('/api/config'),api('/api/stats'),api('/api/products'),api('/api/admin/highlights'),api('/api/admin/announcements'),api('/api/health'),api('/api/categories')]);catalog=cfg.operation_catalog||{operations:[]};$('#stats').innerHTML=Object.entries(s.counts).map(([k,v])=>`<div class="stat"><span class="mut">${k}</span><b>${v}</b></div>`).join('');renderRequests();productsCache=p.items||[];categoriesCache=cats.items||[];await loadCategories($('#pcategory')?.value||'');renderProducts();$('#highlightList').innerHTML=h.items.map(x=>`<div class="listItem"><div><b>${esc(x.title)}</b><div class="mut">${esc(x.subtitle||'')} • ${esc(x.kind)}</div></div><button class="toggle ${x.active?'on':'off'}" onclick="toggleHighlight('${x.id}',${!x.active})">${x.active?'Publié — masquer':'Masqué — publier'}</button></div>`).join('')||'<p class="mut">Aucune mise en avant.</p>';$('#announcementList').innerHTML=a.items.map(x=>`<div class="listItem"><div><b>${esc(x.title)}</b><div class="mut">${esc(x.message)}</div></div><button class="toggle ${x.active?'on':'off'}" onclick="toggleAnnouncement('${x.id}',${!x.active})">${x.active?'Publié — masquer':'Masqué — publier'}</button></div>`).join('');$('#adminConn').textContent=`Synchronisé • ${allRequests.length} demande(s)`}catch(e){console.error(e);$('#adminConn').textContent='Demandes: connexion à vérifier'}}

async function setStatus(id,status){await api('/api/requests/'+id+'/status',{method:'PUT',body:JSON.stringify({status})});refresh()}async function toggleHighlight(id,active){await api('/api/highlights/'+id+'/active',{method:'PUT',body:JSON.stringify({active})});refresh()}async function toggleAnnouncement(id,active){await api('/api/announcements/'+id+'/active',{method:'PUT',body:JSON.stringify({active})});refresh()}
document.querySelectorAll('.adminNav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.adminNav button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#tab-'+b.dataset.tab).classList.add('active');if(b.dataset.tab==='requests')renderRequests()});$('#requestSearch')?.addEventListener('input',renderRequests);
$('#announcementForm').onsubmit=async e=>{e.preventDefault();await api('/api/announcements',{method:'POST',body:JSON.stringify({title:$('#atitle').value,message:$('#amessage').value,type:$('#atype').value})});e.target.reset();refresh()};let timer=null;function scheduleRefresh(){clearInterval(timer);const fast=allRequests.some(x=>['pending','preparing','ready'].includes(x.status));timer=setInterval(()=>{if(!document.hidden)refresh()},fast?2000:10000)}refresh().then(scheduleRefresh).catch(()=>scheduleRefresh());document.addEventListener('visibilitychange',()=>{clearInterval(timer);if(!document.hidden){refresh().then(scheduleRefresh).catch(scheduleRefresh)}});


let productsCache=[];
let categoriesCache=[];
let productCategoryFilter='';
function closeProductForm(){const el=$('#productFormWrap');if(!el)return;el.classList.remove('is-open');el.hidden=true}
async function openProductForm(x=null){$('#productFormWrap').hidden=false;$('#productFormWrap').classList.add('is-open');$('#productFormTitle').textContent=x?'Modifier le produit':'Ajouter un produit';$('#productId').value=x?.id||'';$('#pname').value=x?.name||'';$('#pprice').value=x?.price??'';await loadCategories(x?.category||'');$('#pstock').value=x?.stock??999;$('#pdescription').value=x?.description||'';$('#pavailable').checked=x?!!x.available:true;$('#pimage').value='';$('#imageHint').textContent=x?.image_data?'Photo déjà enregistrée — choisir un fichier pour la remplacer':'Aucune photo sélectionnée';$('#newCategoryRow').hidden=true;}
function editProduct(id){const x=productsCache.find(p=>p.id===id);if(x)openProductForm(x);}
async function toggleProduct(id,available){await api('/api/products/'+id,{method:'PUT',body:JSON.stringify({available})});refresh()}
async function deleteProduct(id){if(confirm('Supprimer ce produit ?')){await api('/api/products/'+id,{method:'DELETE'});refresh()}}
$('#addProductBtn')?.addEventListener('click',()=>openProductForm());
$('#cancelProduct')?.addEventListener('click',()=>closeProductForm());
$('#productCategoryFilter')?.addEventListener('change',e=>{productCategoryFilter=e.target.value;renderProducts()});
$('#pcategory')?.addEventListener('change',()=>{
  const row=$('#newCategoryRow');
  if($('#pcategory').value==='__new__'){row.hidden=false;$('#newCategoryName').focus();}
  else row.hidden=true;
});
$('#cancelCategoryBtn')?.addEventListener('click',()=>{const row=$('#newCategoryRow');row.hidden=true;$('#newCategoryName').value='';if(categoriesCache.length)$('#pcategory').value=categoriesCache[0].name;});
$('#createCategoryBtn')?.addEventListener('click',async()=>{
  const input=$('#newCategoryName'), name=input.value.trim();
  if(!name)return alert('Entrez un nom de catégorie.');
  try{const r=await api('/api/categories',{method:'POST',body:JSON.stringify({name})});await loadCategories(r.name);$('#pcategory').value=r.name;$('#newCategoryRow').hidden=true;input.value='';}
  catch(e){alert(e.message==='category_exists'?'Cette catégorie existe déjà.':'Impossible de créer la catégorie.');}
});
$('#pimage')?.addEventListener('change',()=>{const file=$('#pimage').files[0];$('#imageHint').textContent=file?file.name:'Aucune photo sélectionnée';const preview=$('#imagePreview');if(preview){preview.innerHTML='';if(file&&file.type.startsWith('image/')){const img=document.createElement('img');img.alt='Aperçu de la photo';img.src=URL.createObjectURL(file);preview.appendChild(img);}}});$('#productForm')?.addEventListener('submit',async e=>{e.preventDefault();const id=$('#productId').value;const file=$('#pimage').files[0];let image_data=undefined;if(file){if(!file.type.startsWith('image/'))return alert('Veuillez choisir une image.');if(file.size>1_500_000)return alert('Image trop lourde : maximum 1,5 Mo.');image_data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});}const selectedCategory=$('#pcategory').value;if(!selectedCategory||selectedCategory==='__new__')return alert('Choisissez une catégorie ou créez-la avant d’enregistrer le produit.');const data={name:$('#pname').value,price:$('#pprice').value,category:selectedCategory,stock:$('#pstock').value,description:$('#pdescription').value,available:$('#pavailable').checked};if(image_data!==undefined)data.image_data=image_data;await api(id?'/api/products/'+id:'/api/products',{method:id?'PUT':'POST',body:JSON.stringify(data)});closeProductForm();refresh()});

async function readImage(file){if(!file)return '';if(!file.type.startsWith('image/'))throw Error('Image invalide');if(file.size>1_500_000)throw Error('Image trop lourde : maximum 1,5 Mo');return await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
function identityPreview(){const name=$('#iname')?.value||'Nom du restaurant';const slogan=$('#islogan')?.value||'Votre slogan';$('#identityNamePreview').textContent=name;$('#identitySloganPreview').textContent=slogan}
['iname','islogan'].forEach(id=>$('#'+id)?.addEventListener('input',identityPreview));
async function loadIdentity(){try{const c=await api('/api/config');const x=c.identity||{};updateShopIdentityDock(x);$('#iname').value=x.name||'';$('#islogan').value=x.slogan||'';$('#idescription').value=x.description||'';$('#iphone').value=x.phone||'';$('#iaddress').value=x.address||'';$('#ihours').value=x.hours||'';identityPreview();if(x.logo_data){$('#identityLogoPreview').innerHTML=`<img src="${x.logo_data}" alt="Logo du restaurant">`}$('#identitySummary').innerHTML=`<h2>${esc(x.name||'Nom du restaurant')}</h2><p>${esc(x.slogan||'Aucun slogan renseigné')}</p><p class="mut">${esc(x.address||'Adresse non renseignée')} · ${esc(x.phone||'Téléphone non renseigné')}</p>`;if(!x.name){$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Compléter les informations'}else{$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Modifier les informations'}}catch(e){console.error(e)}}
$('#ilogo')?.addEventListener('change',()=>$('#ilogoHint').textContent=$('#ilogo').files[0]?.name||'Aucun logo sélectionné');$('#editIdentityBtn')?.addEventListener('click',()=>{const el=$('#identityForm');el.hidden=false;el.classList.add('is-open');requestAnimationFrame(()=>el.scrollIntoView({behavior:'smooth',block:'start'}));});$('#cancelIdentityBtn')?.addEventListener('click',()=>{const el=$('#identityForm');el.classList.remove('is-open');el.hidden=true;});
$('#identityForm')?.addEventListener('submit',async e=>{e.preventDefault();try{const logo=await readImage($('#ilogo').files[0]);const cover='';const old=await api('/api/config');const prev=old.identity||{};await api('/api/identity',{method:'PUT',body:JSON.stringify({name:$('#iname').value,slogan:$('#islogan').value,description:$('#idescription').value,phone:$('#iphone').value,address:$('#iaddress').value,hours:$('#ihours').value,logo_data:logo||prev.logo_data||'',cover_data:cover||prev.cover_data||''})});alert('Identité enregistrée');$('#identityForm').classList.remove('is-open');$('#identityForm').hidden=true;$('#editIdentityBtn').textContent='Modifier les informations';loadIdentity();}catch(err){alert(err.message||'Erreur')}});loadIdentity();


bindShopIdentityDock();

if (typeof identity !== 'undefined') updateShopIdentityDock(identity);

function makeFloatingIdentityMovable(button, storageKey){
  if(!button || button.dataset.dragBound) return;
  button.dataset.dragBound='1';
  button.style.touchAction='none';
  let dragging=false, moved=false, startX=0, startY=0, originLeft=0, originTop=0;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem(storageKey)||'null')}catch(_){return null}})();
  const apply=(left,top)=>{
    const maxX=Math.max(0,window.innerWidth-button.offsetWidth);
    const maxY=Math.max(0,window.innerHeight-button.offsetHeight);
    left=Math.max(0,Math.min(maxX,left)); top=Math.max(0,Math.min(maxY,top));
    button.style.left=left+'px'; button.style.top=top+'px';
    button.style.right='auto'; button.style.bottom='auto';
    try{localStorage.setItem(storageKey,JSON.stringify({left,top}))}catch(_){}
  };
  if(saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)){
    requestAnimationFrame(()=>apply(saved.left,saved.top));
  }
  const point=(e)=>({x:e.clientX,y:e.clientY});
  button.addEventListener('pointerdown',e=>{
    if(e.button!==undefined && e.button!==0) return;
    const p=point(e), r=button.getBoundingClientRect();
    dragging=true; moved=false; startX=p.x; startY=p.y; originLeft=r.left; originTop=r.top;
    button.setPointerCapture?.(e.pointerId);
  });
  button.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const p=point(e), dx=p.x-startX, dy=p.y-startY;
    if(Math.abs(dx)>4 || Math.abs(dy)>4)moved=true;
    if(moved)apply(originLeft+dx,originTop+dy);
  });
  const end=e=>{
    if(!dragging)return;
    dragging=false;
    button.releasePointerCapture?.(e.pointerId);
    if(moved){
      button.dataset.suppressClick='1';
      setTimeout(()=>{button.dataset.suppressClick='';},0);
    }
  };
  button.addEventListener('pointerup',end);
  button.addEventListener('pointercancel',end);
  button.addEventListener('click',e=>{
    if(button.dataset.suppressClick==='1'){e.preventDefault();e.stopImmediatePropagation();}
  },true);
  window.addEventListener('resize',()=>{
    const r=button.getBoundingClientRect();
    if(r.width)apply(r.left,r.top);
  });
}

makeFloatingIdentityMovable(document.getElementById('shopIdentityDock'),'nzela_admin_identity_position');
