
function updateClientShopIdentity(identity){
  const d=identity||{};
  const name=d.name||'Ma boutique';
  const logo=d.logo||d.logo_data||d.image_data||'';
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v||'—';};
  set('clientShopName',name); set('clientCardName',name);
  set('clientCardSlogan',d.slogan||'');
  set('clientCardContact',d.contact||d.phone||d.telephone||'—');
  set('clientCardSector',d.sector||d.activity||enterprise?.sector||'—');
  set('clientCardAddress',d.address||'—');
  set('clientCardHours',d.hours||'—');
  set('clientCardDescription',d.description||'');
  ['clientShopLogo','clientCardLogo'].forEach(id=>{
    const e=document.getElementById(id); if(!e)return;
    if(logo){e.src=logo;e.hidden=false;}else{e.removeAttribute('src');e.hidden=true;}
  });
}
function bindClientShopIdentity(){
  const b=document.getElementById('clientShopIdentity'), c=document.getElementById('clientShopCard'), x=document.getElementById('closeClientShopCard');
  if(!b||!c||b.dataset.bound)return; b.dataset.bound='1';
  const close=()=>{c.hidden=true;b.setAttribute('aria-expanded','false');};
  b.addEventListener('click',()=>{if(c.hidden){c.hidden=false;b.setAttribute('aria-expanded','true');}else close();});
  x?.addEventListener('click',close);
}
function bindAppIdentity(){
  const b=document.getElementById('appIdentity'), c=document.getElementById('appIdentityCard'), x=document.getElementById('closeAppIdentity');
  if(!b||!c||b.dataset.bound)return; b.dataset.bound='1';
  const close=()=>{c.hidden=true;b.setAttribute('aria-expanded','false');};
  b.addEventListener('click',()=>{if(c.hidden){c.hidden=false;b.setAttribute('aria-expanded','true');}else close();});
  x?.addEventListener('click',close);
}

const $=s=>document.querySelector(s);let products=[],highlights=[],cart=new Map(),last=null,currentProduct=null,previewOpen=false,enterprise={sector:'',name:'NZELA'};
const THEME_KEY='nzela_theme', THEME_SCALE_KEY='nzela_theme_scale';
function storageGet(key,fallback=null){try{const v=localStorage.getItem(key);return v===null?fallback:v}catch(_){return fallback}}
function storageSet(key,value){try{localStorage.setItem(key,value)}catch(_){} }
function applyThemeScale(value){const scale=Math.max(0,Math.min(100,Number(value)||0));document.body.style.setProperty('--theme-scale',scale+'%');const el=$('#themeScale'),label=$('#themeScaleLabel');if(el)el.value=String(scale);if(label)label.textContent=String(scale)+'%';storageSet(THEME_SCALE_KEY,String(scale));}
function applyTheme(mode,scale){document.body.classList.toggle('light',mode==='light');storageSet(THEME_KEY,mode);applyThemeScale(scale ?? Number(storageGet(THEME_SCALE_KEY,50)));const button=$('#themeToggle');if(button){button.textContent=mode==='light'?'☾':'☼';button.title=mode==='light'?'Passer en mode sombre':'Passer en mode clair'}}
function theme(){const next=document.body.classList.contains('light')?'dark':'light';applyTheme(next,Number(storageGet(THEME_SCALE_KEY,50)))}
function initTheme(){const mode=storageGet(THEME_KEY,'dark')==='light'?'light':'dark';applyTheme(mode,Number(storageGet(THEME_SCALE_KEY,50)));$('#themeToggle')?.addEventListener('click',theme);$('#themeScale')?.addEventListener('input',e=>applyThemeScale(e.target.value));}

const CART_COLLAPSED_KEY='nzela_cart_collapsed';
function setCartCollapsed(collapsed){const panel=$('#cart');if(!panel)return;panel.classList.toggle('collapsed',collapsed);storageSet(CART_COLLAPSED_KEY,collapsed?'1':'0');const btn=$('#cartCollapse');if(btn){btn.textContent=collapsed?'+':'−';btn.title=collapsed?'Agrandir':'Réduire';btn.setAttribute('aria-label',btn.title)}}
function initCartCollapse(){setCartCollapsed(storageGet(CART_COLLAPSED_KEY,'0')==='1');$('#cartCollapse')?.addEventListener('click',e=>{e.stopPropagation();setCartCollapsed(!$('#cart').classList.contains('collapsed'))})}
const HISTORY_KEY='nzela_order_history';
const money=n=>new Intl.NumberFormat('fr-FR').format(n)+' FCFA';
function getTrackedOrders(){try{return JSON.parse(storageGet(HISTORY_KEY,'[]')||'[]').slice(0,20)}catch{return[]}}
function trackOrder(order){const list=getTrackedOrders().filter(x=>x.request_id!==order.request_id);list.unshift({request_id:order.request_id,queue_number:order.queue_number,total:order.total,created_at:new Date().toISOString()});storageSet(HISTORY_KEY,JSON.stringify(list.slice(0,20)))}
async function refreshTrackedOrders(){const list=getTrackedOrders();if(!list.length){$('#history').innerHTML='<p class="empty">Aucune commande sur cet appareil.</p>';return}const results=await Promise.all(list.map(async x=>{try{return {x,d:await api('/api/requests/'+encodeURIComponent(x.request_id))}}catch{return {x,d:null}}}));const rows=results.map(({x,d})=>d?`<article class="historyRow"><div><b>Commande #${String(d.queue_number).padStart(3,'0')}</b><small>${esc(d.created_at||x.created_at)}</small></div><div><strong>${money(d.total)}</strong><span class="status status-${esc(d.status)}">${({pending:'En attente',preparing:'En préparation',ready:'Prête',completed:'Terminée',cancelled:'Annulée'})[d.status]||d.status}</span></div></article>`:`<article class="historyRow"><div><b>Commande #${String(x.queue_number).padStart(3,'0')}</b><small>Non disponible actuellement</small></div><strong>${money(x.total)}</strong></article>`);$('#history').innerHTML=rows.join('')}
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
async function api(p,o={}){let r=await fetch(p,{cache:'no-store',...o,headers:{'Content-Type':'application/json',...(o.headers||{})}}),d=await r.json();if(!r.ok)throw Error(d.error||'Erreur réseau');return d}
function pulse(el){el?.classList.remove('pulse');if(el){void el.offsetWidth;el.classList.add('pulse')}}
let catalog={operations:[]}; const kindInfo={};
function opKind(p){return p?.operation_kind||catalog.operations.find(o=>o.id===p?.id)?.kind||''}
function opSpec(kind){return catalog.operations.find(o=>o.kind===kind)||{kind,name:kind,icon:'•',description:'',fields:[]}}
function isRestaurant(){return enterprise.sector==='restaurant'}
function quantityMode(p){return opSpec(opKind(p)).quantity_mode||'single'}
function escAttr(s){return esc(s).replace(/`/g,'&#096;')}
function productImageMarkup(p,info,cls='productImage'){const src=typeof p?.image_data==='string'&&p.image_data.startsWith('data:image/')?p.image_data:'';return src?`<img class="${cls}" src="${src}" alt="${esc(p.name)}" loading="lazy">`:`<span class="placeholderImage ${cls}" aria-label="Aucune photo">${info.icon||'🍽️'}</span>`;}

function renderHighlights(){ $('#highlightGrid').innerHTML=highlights.length?highlights.map((h,i)=>`<article class="highlight serviceHighlight" style="--i:${i}"><div class="serviceGlyph">${h.product_id?(opSpec(opKind(products.find(p=>p.id===h.product_id))).icon||'•'):'•'}</div><span class="badge">${esc(h.subtitle||'Opération')}</span><h3>${esc(h.title)}</h3><p>${esc(h.description||'')}</p><button class="actionBtn" data-pid="${esc(h.product_id||'')}">${esc(h.cta||'Choisir')} <span>→</span></button></article>`).join(''):'<div class="empty">Aucune opération mise en avant.</div>'}
function render(){let q=String($('#search').value||'').trim().toLowerCase(),c=$('#cat').value;let list=products.filter(p=>{const name=String(p.name||''),category=String(p.category||''),description=String(p.description||'');return (!q||name.toLowerCase().includes(q)||category.toLowerCase().includes(q)||description.toLowerCase().includes(q))&&(!c||category===c)});$('#grid').innerHTML=list.map((p,i)=>{const k=opKind(p),info=opSpec(k),multi=quantityMode(p)==='multiple',qty=cart.get(p.id)||0;return `<article class="product serviceProduct ${p.available?'':'off'}" style="--i:${i}" data-product="${p.id}" data-category="${esc(p.category)}"><div class="productTop"><label>${esc(p.category)}</label><span class="serviceMiniIcon">${info.icon||'🍽️'}</span></div><button class="imageButton serviceVisual" data-view="${p.id}" aria-label="Voir ${esc(p.name)}">${productImageMarkup(p,info,'productImage')}<span class="serviceVisualText">${esc(p.name)}</span></button><h3>${esc(p.name)}</h3><p>${esc(p.description||'')}</p><div class="foot"><div><div class="price operationPrice">${money(p.price)}</div><div class="stock">${p.available?'Disponible':'Indisponible'}</div></div>${multi?`<div class="qtyControl"><button data-qty="-" data-id="${p.id}">−</button><b>${qty}</b><button data-qty="+" data-id="${p.id}">+</button></div>`:`<button class="addBtn" ${p.available?'':'disabled'} data-id="${p.id}">${cart.has(p.id)?'Ajouté':'Ajouter'} <span>${cart.has(p.id)?'✓':'+'}</span></button>`}</div></article>`}).join('')||'<p class="empty">Aucun article trouvé.</p>';renderCart()}
let renderFrame=0;function scheduleRender(){if(renderFrame)return;renderFrame=requestAnimationFrame(()=>{renderFrame=0;render()})}
function bindCatalogDelegation(){const grid=$('#grid'),high=$('#highlightGrid');grid?.addEventListener('click',e=>{const qty=e.target.closest('[data-qty]');if(qty){e.stopPropagation();change(qty.dataset.id,qty.dataset.qty==='+'?1:-1);return}const addBtn=e.target.closest('.addBtn');if(addBtn){e.stopPropagation();pulse(addBtn);add(addBtn.dataset.id);return}const image=e.target.closest('.imageButton');if(image){e.stopPropagation();openProduct(products.find(x=>x.id===image.dataset.view));return}const card=e.target.closest('.product');if(card&&!e.target.closest('button'))openProduct(products.find(x=>x.id===card.dataset.product))});high?.addEventListener('click',e=>{const b=e.target.closest('.actionBtn');if(!b)return;pulse(b);const p=products.find(x=>x.id===b.dataset.pid);if(p)openProduct(p)})}
function add(id){if(!id)return;if(quantityMode(products.find(x=>x.id===id))==='multiple')cart.set(id,(cart.get(id)||0)+1);else if(cart.has(id))cart.delete(id);else cart.set(id,1);render();if(!$('#cart').classList.contains('collapsed'))$('#cart').classList.add('cartAttention');setTimeout(()=>$('#cart')?.classList.remove('cartAttention'),500)}
function change(id,d){const n=(cart.get(id)||0)+d;if(n<=0)cart.delete(id);else cart.set(id,n);render()}
function renderCart(){let html='',total=0;for(const [id,qty] of cart){const p=products.find(x=>x.id===id);if(!p)continue;total+=Number(p.price||0)*qty;html+=`<div class="cartRow"><span>${esc(p.name)} × ${qty}</span><button onclick="change('${id}',-1)" aria-label="Retirer">×</button></div>`}$('#count').textContent=[...cart.values()].reduce((a,b)=>a+b,0);$('#total').textContent=cart.size?money(total):'À préciser';$('#items').className=html?'cartitems':'empty';$('#items').innerHTML=html||'Choisissez un article pour commencer.';$('#order').disabled=!cart.size}
function closeProductPreview(){if(!previewOpen)return;$('#productModal')?.classList.add('hidden');$('#productWorkspace').innerHTML='';previewOpen=false;document.removeEventListener('keydown',handleEscape)}
function handleEscape(e){if(e.key==='Escape')closeProductPreview()}
function showPage(page){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$('#page-'+page).classList.add('active');document.querySelectorAll('.navItem').forEach(x=>x.classList.toggle('active',x.dataset.page===page));window.scrollTo({top:0,behavior:'smooth'})}document.querySelectorAll('.navItem').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
initTheme();
function fieldFor(kind,index){const spec=opSpec(kind),base=`data-op-index="${index}"`;let fields=spec.fields.map(f=>{if(f.type==='select')return `<label class="operationField"><span>${esc(f.label||f.name)}</span><select ${base} data-field="${escAttr(f.name)}" ${f.required?'required':''}>${(f.options||[]).map(o=>`<option value="${escAttr(o.value)}">${esc(o.label)}</option>`).join('')}</select></label>`;return `<label class="operationField"><span>${esc(f.label||f.name)}</span><input ${base} data-field="${escAttr(f.name)}" type="${f.type||'text'}" ${f.min!=null?`min="${f.min}"`:''} ${f.required?'required':''} placeholder="${escAttr(f.label||f.name)}"></label>`}).join('');return `<div class="operationFormCard"><div class="operationFormHead"><b>${esc(spec.icon||'•')} ${esc(spec.name)}</b><span>Opération ${index+1}</span></div>${fields}</div>`}
function operationFormMarkup(p){const k=opKind(p);if(isRestaurant()&&quantityMode(p)==='multiple'){const qty=cart.get(p.id)||1;return `<div class="restaurantQuickOrder"><div class="toolSectionLabel">COMMANDE</div><div class="restaurantOrderRow"><div><div class="restaurantDishName">${esc(p.name)}</div><div class="restaurantDishPrice">${money(p.price)} / unité</div></div><div class="restaurantQty" aria-label="Quantité"><button type="button" data-modal-qty="-" aria-label="Diminuer">−</button><b data-modal-qty-value>${qty}</b><button type="button" data-modal-qty="+" aria-label="Augmenter">+</button></div></div><button class="primary previewAction" data-add="${p.id}">${cart.has(p.id)?'Mettre à jour la commande':'Commander'} <span>→</span></button></div>`}if(k==='transfer')return `<form class="cabinTransferForm" data-transfer-form><div class="toolSectionLabel">DEMANDE DE TRANSFERT</div><label class="operationField"><span>Numéro de téléphone</span><input data-field="phone" type="tel" inputmode="tel" autocomplete="tel" required placeholder="Numéro de téléphone"></label><label class="operationField"><span>Nom</span><input data-field="recipient_name" type="text" autocomplete="name" required placeholder="Nom"></label><label class="operationField"><span>Montant à envoyer (FCFA)</span><input data-field="amount" type="number" inputmode="numeric" min="1" required placeholder="Montant à envoyer (FCFA)"></label><button class="primary transferSubmit" type="submit">Envoyer la demande <span>→</span></button></form>`;return `<div class="directOperationForm"><div class="toolSectionLabel">PARAMÈTRES</div>${fieldFor(k,0)}</div>`}
function openProduct(p){
  if(!p)return;
  const modal=$('#productModal'),workspace=$('#productWorkspace'),k=opKind(p),info=opSpec(k);
  if(!modal||!workspace)return;
  const restaurant=isRestaurant();
  const image=productImageMarkup(p,info,'previewImage');
  const available=p.available!==false;
  workspace.innerHTML=`<section class="productPreview visible" role="dialog" aria-modal="true" aria-label="${esc(p.name)}">
    <div class="previewCard ${k==='transfer'?'transferOnlyCard':restaurant?'restaurantOnlyCard':'directFormCard'}">
      <button type="button" class="productPreviewClose" aria-label="Fermer" title="Fermer">×</button>
      <div class="previewMain">
        <div class="previewMedia">${image}<div class="previewMediaShade"></div></div>
        <div class="previewInfo">
          <div class="previewIdentity">
            <div><span class="previewCategorySimple">${esc(p.category||info.name||'Service')}</span><h2>${esc(p.name)}</h2></div>
            <span class="previewPriceSimple">${money(p.price)}</span>
          </div>
          <p class="previewDescription">${esc(p.description||info.help||'')}</p>
          <div class="previewAvailabilitySimple ${available?'isAvailable':'isUnavailable'}">${available?'Disponible':'Indisponible'}</div>
          ${operationFormMarkup(p)}
        </div>
      </div>
    </div>
  </section>`;
  modal.classList.remove('hidden');
  previewOpen=true;
  const root=workspace.querySelector('.productPreview');
  root.onclick=closeProductPreview;
  workspace.querySelector('.previewCard').onclick=e=>e.stopPropagation();
  workspace.querySelector('.productPreviewClose')?.addEventListener('click',e=>{e.stopPropagation();closeProductPreview()});
  const transferForm=workspace.querySelector('[data-transfer-form]');
  if(transferForm){transferForm.onsubmit=async e=>{e.preventDefault();const values={};transferForm.querySelectorAll('[data-field]').forEach(el=>values[el.dataset.field]=el.value.trim());const submit=transferForm.querySelector('button[type="submit"]');if(submit)submit.disabled=true;try{const d=await api('/api/requests',{method:'POST',body:JSON.stringify({customer_name:values.recipient_name,customer_phone:values.phone,items:[{product_id:p.id,quantity:1,kind:'transfer',details:values}]})});last=d;trackOrder(d);refreshTrackedOrders();cart.delete(p.id);renderCart();closeProductPreview();$('#qn').textContent='#'+String(d.queue_number).padStart(3,'0');$('#status').textContent='En attente';$('#done').classList.remove('hidden')}catch(err){alert(err.message);if(submit)submit.disabled=false}};return}
  const qtyMinus=workspace.querySelector('[data-modal-qty="-"]'),qtyPlus=workspace.querySelector('[data-modal-qty="+"]'),qtyValue=workspace.querySelector('[data-modal-qty-value]');
  if(qtyValue){let q=cart.get(p.id)||1;const setQ=n=>{q=Math.max(1,n);qtyValue.textContent=q};qtyMinus.onclick=()=>setQ(q-1);qtyPlus.onclick=()=>setQ(q+1);workspace.querySelector('[data-add]').onclick=e=>{e.stopPropagation();cart.set(p.id,q);render();closeProductPreview();openRequestForm()};return}
  const addButton=workspace.querySelector('[data-add]');
  if(addButton)addButton.onclick=e=>{e.stopPropagation();const values={};workspace.querySelectorAll('[data-op-index="0"][data-field]').forEach(el=>values[el.dataset.field]=el.value);window._directOperationDraft={product_id:p.id,kind:k,details:values};cart.set(p.id,1);renderCart();closeProductPreview();openRequestForm(window._directOperationDraft)};
}
function openRequestForm(draft){const fields=$('#operationFields'),summary=$('#requestSummary');let arr=[...cart].map(([id])=>products.find(p=>p.id===id)).filter(Boolean);fields.innerHTML=arr.map((p,i)=>{let html=fieldFor(opKind(p),i);if(draft&&draft.product_id===p.id){setTimeout(()=>{for(const [k,v] of Object.entries(draft.details||{})){const el=fields.querySelector(`[data-op-index="${i}"][data-field="${escAttr(k)}"]`);if(el)el.value=v}},0)}return html}).join('');summary.innerHTML=`<b>${arr.length} opération${arr.length>1?'s':''}</b><span>${arr.map(p=>esc(p.name)).join(' • ')}</span>`;$('#modal').classList.remove('hidden')}
$('#order').onclick=openRequestForm;$('#close').onclick=()=>$('#modal').classList.add('hidden');$('#finish').onclick=()=>{$('#done').classList.add('hidden');showPage('history');refreshTrackedOrders()};$('#form').onsubmit=async e=>{e.preventDefault();let arr=[...cart].map(([id])=>products.find(p=>p.id===id)).filter(Boolean);let items=arr.map((p,i)=>{let d={};document.querySelectorAll(`[data-op-index="${i}"][data-field]`).forEach(el=>d[el.dataset.field]=el.value);return {product_id:p.id,quantity:cart.get(p.id)||1,kind:opKind(p),details:d}});try{let d=await api('/api/requests',{method:'POST',body:JSON.stringify({customer_name:$('#name').value,customer_phone:$('#phone').value,items})});last=d;trackOrder(d);refreshTrackedOrders();$('#modal').classList.add('hidden');$('#qn').textContent='#'+String(d.queue_number).padStart(3,'0');$('#status').textContent='En attente';$('#done').classList.remove('hidden');cart.clear();render()}catch(err){alert(err.message)}};
let clientIdentitySignature='';
async function syncClientShopIdentity(){
  try{
    const r=await api('/api/identity');
    const d=r.identity||{};
    const signature=JSON.stringify(d);
    if(signature!==clientIdentitySignature){
      clientIdentitySignature=signature;
      enterprise={...enterprise,...d};
      updateClientShopIdentity(d);
    }
  }catch(_){}
}

async function load(options={}){try{const conn=$('#conn');if(conn)conn.hidden=true;let [cfg,p,h,n]=await Promise.all([api('/api/config'),api('/api/products'),api('/api/highlights'),api('/api/announcements')]);const previousCategory=$('#cat')?.value||'';enterprise={...(cfg.enterprise||{}),...(cfg.identity||{})};updateClientShopIdentity(enterprise);catalog=cfg.operation_catalog||{operations:[]};for(const o of catalog.operations)kindInfo[o.kind]=o;products=Array.isArray(p.items)?p.items:[];highlights=Array.isArray(h.items)?h.items:[];renderHighlights();const categories=[...new Set(products.map(x=>String(x.category||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'fr'));$('#cat').innerHTML='<option value="">Toutes les catégories</option>'+categories.map(c=>`<option value="${escAttr(c)}">${esc(c)}</option>`).join('');if(categories.includes(previousCategory))$('#cat').value=previousCategory;render();$('#announcements').innerHTML=n.items.map(x=>`<article class="announcement"><div class="announcementIcon">${x.type==='warning'?'!':'i'}</div><div><h3>${esc(x.title)}</h3><p>${esc(x.message)}</p><small>${esc(x.created_at||'')}</small></div></article>`).join('')||'<p class="empty">Aucune annonce.</p>';$('#annBadge').textContent=n.items.length;$('#annBadge').classList.toggle('hidden',!n.items.length);refreshTrackedOrders()}catch(e){const el=$('#conn');if(el&&!options.silent){el.textContent='● Hors ligne';el.hidden=false;el.title='Connexion au serveur indisponible'} console.error('NZELA client load failed',e)}}
function initCatalogInteractions(){
  const search=$('#search'), clear=$('#searchClear'), cat=$('#cat');
  search?.addEventListener('input',scheduleRender);
  clear?.addEventListener('click',()=>{if(search){search.value='';search.focus();render()}});
  cat?.addEventListener('change',async()=>{
    // L'affichage du filtre est local et donc immédiat. On déclenche ensuite
    // une requête automatique pour récupérer l'état le plus récent du catalogue.
    render();
    await load({silent:true});
  });
}

syncClientShopIdentity();
load();
initTheme();
initCartCollapse();
bindAppIdentity();
bindClientShopIdentity();
initCatalogInteractions();
bindCatalogDelegation();
let identityTimer=setInterval(()=>{if(!document.hidden)syncClientShopIdentity()},30000);
// Plus de rechargement aveugle toutes les 10 secondes : les actions utilisateur
// déclenchent les rafraîchissements utiles, avec un filet de sécurité plus lent.
let loadTimer=setInterval(()=>{if(!document.hidden)load({silent:true})},60000);
document.addEventListener('visibilitychange',()=>{
  if(!document.hidden)load({silent:true});
});


// 2.2 — Menu accessible immédiatement sans long défilement
function initSimpleClientHome(){
  const button=$('#openMenu');
  if(!button) return;
  button.addEventListener('click',()=>{
    document.querySelectorAll('.menuContent').forEach(el=>{el.classList.remove('hiddenMenu');el.classList.add('menuVisible');});
    button.textContent='Menu ouvert ✓';
    button.disabled=true;
    document.querySelector('.catalog')?.scrollIntoView({behavior:'smooth',block:'start'});
  });
}
initSimpleClientHome();

function makeFloatingIdentityMovable(button, storageKey){
  if(!button || button.dataset.dragBound) return;
  button.dataset.dragBound='1';
  button.style.touchAction='none';
  let dragging=false, moved=false, startX=0, startY=0, originLeft=0, originTop=0;
  const saved=(()=>{try{return JSON.parse(localStorage.getItem(storageKey)||'null')}catch(_){return null}})();
  const apply=(left,top)=>{
    const maxX=Math.max(0,window.innerWidth-button.offsetWidth);
    const maxY=Math.max(0,window.innerHeight-button.offsetHeight);
    left=Math.max(0,Math.min(maxX,left)); top=Math.max(0,Math.min(maxY,top));
    button.style.left=left+'px'; button.style.top=top+'px';
    button.style.right='auto'; button.style.bottom='auto';
    try{localStorage.setItem(storageKey,JSON.stringify({left,top}))}catch(_){}
    window.dispatchEvent(new CustomEvent('nzela-shop-position'));
  };
  if(saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)){
    requestAnimationFrame(()=>apply(saved.left,saved.top));
  }
  const point=(e)=>({x:e.clientX,y:e.clientY});
  button.addEventListener('pointerdown',e=>{
    if(e.button!==undefined && e.button!==0) return;
    const p=point(e), r=button.getBoundingClientRect();
    dragging=true; moved=false; startX=p.x; startY=p.y; originLeft=r.left; originTop=r.top;
    button.setPointerCapture?.(e.pointerId);
  });
  button.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const p=point(e), dx=p.x-startX, dy=p.y-startY;
    if(Math.abs(dx)>4 || Math.abs(dy)>4)moved=true;
    if(moved)apply(originLeft+dx,originTop+dy);
  });
  const end=e=>{
    if(!dragging)return;
    dragging=false;
    button.releasePointerCapture?.(e.pointerId);
    if(moved){
      button.dataset.suppressClick='1';
      setTimeout(()=>{button.dataset.suppressClick='';},0);
    }
  };
  button.addEventListener('pointerup',end);
  button.addEventListener('pointercancel',end);
  button.addEventListener('click',e=>{
    if(button.dataset.suppressClick==='1'){e.preventDefault();e.stopImmediatePropagation();}
  },true);
  window.addEventListener('resize',()=>{
    const r=button.getBoundingClientRect();
    if(r.width)apply(r.left,r.top);
  });
}

makeFloatingIdentityMovable(document.getElementById('clientShopIdentity'),'nzela_client_identity_position');

// 2.18.16 — le bouton reste toujours sous l'icône, même après déplacement de celle-ci
function syncBackToTop(){
  const shop=document.getElementById('clientShopIdentity');
  const topBtn=document.getElementById('backToTop');
  if(!shop || !topBtn) return;
  const r=shop.getBoundingClientRect();
  const gap=8;
  topBtn.style.left=Math.round(r.left + (r.width-topBtn.offsetWidth)/2)+'px';
  topBtn.style.top=Math.round(r.bottom + gap)+'px';
  topBtn.style.right='auto';
}
window.addEventListener('nzela-shop-position',syncBackToTop);
window.addEventListener('resize',syncBackToTop);
requestAnimationFrame(syncBackToTop);

document.getElementById('backToTop')?.addEventListener('click',()=>{
  window.scrollTo({top:0,behavior:'smooth'});
});
