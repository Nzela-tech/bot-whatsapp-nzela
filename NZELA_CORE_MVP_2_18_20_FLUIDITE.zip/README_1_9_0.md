# NZELA CORE 1.9.0 — Contexte Restaurant

Cette version utilise le même moteur configurable avec un contexte métier `restaurant`.

## Menu initial
- Poulet braisé — 3 500 FCFA
- Poisson braisé — 4 000 FCFA
- Spaghetti viande — 3 000 FCFA
- Frites — 1 000 FCFA
- Riz — 1 000 FCFA
- Jus naturel — 1 500 FCFA
- Eau — 500 FCFA
- Salade de fruits — 1 500 FCFA

## Flux
Client → menu → quantités → commande → serveur → SQLite → tableau de bord.

La capacité générique ajoutée est `quantity_mode: multiple`, configurée par le catalogue. Les règles spécifiques à la cabine ne sont pas appliquées au contexte restaurant.

Lancement Windows : `py -3 server\main.py`
