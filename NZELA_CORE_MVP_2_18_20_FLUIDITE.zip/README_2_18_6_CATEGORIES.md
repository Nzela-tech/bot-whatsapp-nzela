# NZELA CORE — 2.18.6 — Catégories produits

Évolution ciblée de la base 2.18.5 :

- Les catégories de produits sont désormais persistées dans SQLite.
- Le formulaire produit propose une liste déroulante des catégories existantes.
- Le formulaire permet de créer une nouvelle catégorie sans quitter le formulaire ; elle est immédiatement ajoutée à la liste et sélectionnée.
- Les doublons de catégories sont refusés sans distinction de casse.
- L'onglet Produits dispose d'un filtre par catégorie pour retrouver rapidement les produits.
- Les catégories historiques sont migrées automatiquement depuis les produits existants.
- Les produits initiaux créent également leurs catégories lors d'une installation neuve.
- La logique client et serveur reste compatible avec les produits existants.
- Le thème 2.18.5 et son bouton ☼/☾ + curseur 0–100 sont conservés sans modification de comportement.
