# NZELA CORE 2.18.18 — carte détail

- Arrière-plan de la carte détail flouté et translucide, sans panneau visible supplémentaire.
- Carte produit conservée compacte, sans défilement.
- Opération de commande rendue explicite dans la carte restaurant : bouton « Commander » / mise à jour de commande.
- Version alignée en 2.18.18.
