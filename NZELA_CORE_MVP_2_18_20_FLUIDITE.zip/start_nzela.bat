@echo off
cd /d "%~dp0"
echo NZELA CORE NETWORK 0.4
echo.
py -3 server\main.py
pause
