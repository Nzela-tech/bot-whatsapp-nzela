# NZELA CORE — 2.18.8 — Correctifs audit client

Base : 2.18.6 CATEGORIES.

Correctifs ciblés issus de l’audit client :
- correction de la cohérence restaurant : le secteur de la configuration active est explicitement `restaurant`, ce qui réactive le parcours client restaurant attendu ;
- initialisation de l’identité client avec `enterprise` + `identity` ;
- filtre de catégorie conservé pendant les rafraîchissements ;
- libellé du filtre rétabli à « Toutes les catégories » ;
- rendu client plus robuste face à des champs produit absents/null ;
- correction de la gestion d’erreur réseau : l’élément `#conn` existe désormais et l’erreur originale est journalisée ;
- ajout d’un indicateur de connexion non intrusif ;
- stockage local client protégé contre les environnements où `localStorage` est indisponible ;
- synchronisation d’identité passée de 1 s à 30 s ;
- version alignée en 2.18.8.

Le polling catalogue reste à 10 s afin de conserver la détection relativement rapide des changements de disponibilité/stock.


## 2.18.8 — Rafraîchissement automatique client
- Le changement de catégorie filtre immédiatement le catalogue local.
- Une requête automatique `/api/products` est ensuite lancée en arrière-plan pour récupérer l’état le plus récent.
- La recherche et l’effacement de recherche sont désormais réactifs immédiatement.
- Suppression du polling catalogue toutes les 10 secondes ; filet de sécurité à 60 secondes.
- Un changement de visibilité déclenche un rafraîchissement automatique.
