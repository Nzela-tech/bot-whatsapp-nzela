# Règles Empty Real

Le projet ne doit jamais créer automatiquement :
- un produit ;
- une image ;
- une commande ;
- un client ;
- une vente.

Les seuls enregistrements autorisés proviennent :
- du formulaire administrateur ;
- du formulaire client ;
- d'une future API authentifiée.

Les fichiers de cache Python et les anciennes bases ne sont pas livrés dans le ZIP.
