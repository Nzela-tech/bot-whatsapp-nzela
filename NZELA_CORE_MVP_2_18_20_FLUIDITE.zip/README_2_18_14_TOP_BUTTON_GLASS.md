# NZELA CORE MVP 2.18.14 — bouton retour en haut

- Le bouton `↑` est placé sous l’icône boutique, centré avec elle.
- Sa position suit automatiquement l’icône lorsque celle-ci est déplacée.
- Fond verre/translucide avec flou et contraste adaptés au thème clair/sombre.
- La flèche reste fortement visible.
- Aucun changement au fonctionnement du catalogue, des catégories ou de la carte produit.
