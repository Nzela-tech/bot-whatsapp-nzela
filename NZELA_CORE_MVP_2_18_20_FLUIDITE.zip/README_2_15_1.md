# NZELA CORE MVP 2.15.1 — Correction administrateur

## Problème corrigé

La version 2.15.0 contenait une injection JavaScript incorrecte :
les caractères `\n` avaient été insérés littéralement dans le fichier,
ce qui empêchait le navigateur de compiler le script. Résultat :
tous les boutons administrateur semblaient ne plus fonctionner.

## Correction

- JavaScript réparé.
- Fonctionnement des boutons restauré.
- Mise à jour du logo et du nom de boutique branchée après chargement de l’identité.
- Aucun changement de données métier.
