# NZELA CORE MVP 2.1.0 — Empty Real + Theme Scale

Base issue de la version 1.9.1, avec une règle stricte :

- aucune commande fictive ;
- aucun produit fictif ;
- aucune image fictive ;
- aucune base de démonstration ;
- toutes les données sont créées par l'administrateur ou par un vrai client.

Cette version conserve le moteur réel, le catalogue, les commandes et l'espace administrateur.
Elle renforce aussi l'échelle visuelle du thème :

1. fond spatial plus profond ;
2. hiérarchie typographique plus nette ;
3. cartes avec niveaux de profondeur ;
4. états de commande plus lisibles ;
5. interactions plus visibles ;
6. interface responsive ;
7. administration orientée traitement réel des commandes.

L'administrateur doit pouvoir :
- ouvrir une commande ;
- voir le client, téléphone, adresse, articles et total ;
- voir l'historique ;
- changer le statut ;
- ajouter une note ;
- suivre le passage de reçue à préparation, prête, livrée ou annulée.

Lancement Windows :

    py -3 server/main.py

Puis :
- Client : http://127.0.0.1:8787/
- Administration : http://127.0.0.1:8787/admin.html

Avant le premier lancement, le dossier data doit rester vide.
La base réelle sera créée automatiquement au démarrage.


## Version 2.2.0 — Simplicité client et admin
- Espace administrateur sombre uniquement, centré, sans mode clair ni échelle de thème.
- Accueil client court avec bouton « Voir le menu » immédiatement visible.
- Menu chargé/affiché à la demande pour éviter une longue page dès l’entrée.


Version 2.6.0: administrateur sombre uniquement, espace centré, échelle Compact/Normal/Confort dans le mode sombre.


## 2.8.1
Correction : les images enregistrées dans `image_data` sont maintenant affichées dans les cartes client et dans la fiche détaillée restaurant.

Version 2.10.0 : identité réelle du restaurant, logo/photo, nom et slogan, logo plateforme N uniquement.

## 2.11.1
Correction: l’onglet Restaurant est désormais correctement séparé de Produits. Lors de la première ouverture sans identité enregistrée, le formulaire est automatiquement proposé. Après sauvegarde, les informations sont visibles et modifiables.

## 2.12.0
- Espace client : suppression du statut visuel En ligne et de son point.
- Suppression des mentions de marque textuelles autour du symbole N dans l’en-tête client.
- Suppression des mentions visibles liées à l’IA dans les pages web.
