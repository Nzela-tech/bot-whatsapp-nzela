# NZELA CORE MVP 2.18.4

## Informations boutique côté client en temps réel
- Le client reçoit les informations d'identité de la boutique depuis `/api/identity`.
- Une synchronisation légère vérifie les modifications toutes les 1 seconde, sans recharger le catalogue.
- Le logo, nom, slogan, contact, secteur, adresse, horaires et description sont actualisés après l'enregistrement côté entreprise.
- Le logo de la boutique est un point flottant cliquable dans l'espace client et ouvre les informations de la boutique.
- Le logo NZELA CORE dans la barre supérieure est également cliquable et ouvre les informations de l'application.
- Les informations restent servies sans cache (`no-store`).

## Principe
Modification dans l'espace entreprise → enregistrement serveur → prochaine synchronisation du client → mise à jour de l'affichage, sans actualisation manuelle de la page.
