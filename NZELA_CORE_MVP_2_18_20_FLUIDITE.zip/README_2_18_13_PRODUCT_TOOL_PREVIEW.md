# NZELA CORE MVP 2.18.13 — Product preview tool

Amélioration ciblée de la carte affichée après clic sur un produit.

- Présentation en deux zones : média + outil d’action.
- Identité claire du service et disponibilité.
- Prix et catégorie visibles sans masquer l’action.
- Formulaires et commande intégrés dans une zone opérationnelle.
- Responsive mobile avec image compacte et action immédiatement accessible.
- Fermeture par ×, clic hors carte et Escape conservés.
- Aucun changement du catalogue, du panier ou du mécanisme de commande hors de cette présentation.
