# NZELA CORE MVP 2.18.11 — Fiche produit

Correctifs client :
- Ajout d’une croix de fermeture visible sur la fiche produit.
- Fermeture par clic sur la croix, clic sur l’arrière-plan et touche Échap.
- Affichage de la photo du produit dans la fiche pour les parcours restaurant et opération directe/transfert.
- Conservation du fonctionnement existant de la fiche et du panier.

Tests : Python, JavaScript et JSON validés.
