# NZELA CORE MVP 2.16.0 — Identité boutique côté client

Le client voit en permanence le logo rond et le nom de la boutique dans l’interface client.
Un clic sur le bloc ouvre une carte contenant les informations de base disponibles :
nom, logo, slogan, contact et activité.
