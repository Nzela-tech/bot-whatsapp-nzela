# NZELA Core MVP 2.17.0

Correction des en-têtes client et administrateur.

- Barre principale conservée en haut pendant le défilement.
- Identité de boutique placée dans un dock compact au-dessus.
- Même logique sur client et administrateur.
- Compatible avec les thèmes et les échelles existantes.
- Correction CSS ciblée, sans modification du moteur métier.
