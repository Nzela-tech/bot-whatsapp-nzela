# NZELA CORE MVP 2.18.13 — Product preview tool

Improved the client product preview without redesigning the rest of the interface.

- clearer product identity: category, availability, title, description, price;
- two-column desktop layout with dedicated media and action areas;
- compact mobile layout;
- quantity control remains directly usable for restaurant products;
- action button is visually prominent and disabled when the product is unavailable;
- operation forms remain functional;
- close button, backdrop close and Escape remain available;
- existing 2.18.x category/filter, shop button and product-photo behavior preserved.
