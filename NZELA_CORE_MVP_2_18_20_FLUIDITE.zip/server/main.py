import json, os, socket, sqlite3, threading, uuid, base64
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parents[1]; WEB=ROOT/'web'; DATA=ROOT/'data'; DB=DATA/'nzela.db'
CONFIG_FILE=ROOT/'config'/'enterprise.json'
MODULES_DIR=ROOT/'modules'

VERSION='2.18.20'

def load_config():
    cfg=json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
    cat=json.loads((ROOT/cfg['operation_catalog']).read_text(encoding='utf-8'))
    cfg['operation_catalog_data']=cat
    return cfg

CONFIG=load_config()
OPERATIONS={x['kind']:x for x in CONFIG['operation_catalog_data']['operations']}
OPERATIONS_BY_ID={x['id']:x for x in CONFIG['operation_catalog_data']['operations']}

ROOT=Path(__file__).resolve().parents[1]; WEB=ROOT/'web'; DATA=ROOT/'data'; DB=DATA/'nzela.db'
HOST=os.getenv('NZELA_HOST','0.0.0.0'); PORT=int(os.getenv('NZELA_PORT','8787')); LOCK=threading.RLock()
STATUSES=('pending','preparing','ready','completed','cancelled')

def field_schema(kind): return OPERATIONS.get(kind,{}).get('fields',[])

def validate_operation_config(kind, details):
    spec=OPERATIONS.get(kind)
    if not spec: raise ValueError('unknown_operation')
    if not isinstance(details,dict): raise ValueError('details_required')
    for f in spec.get('fields',[]):
        v=str(details.get(f['name'],'')).strip()
        if f.get('required') and not v: raise ValueError(f"{f['name']}_required")
        if f.get('type')=='number' and v:
            try:
                n=int(v)
                if n < int(f.get('min',0)): raise ValueError(f"{f['name']}_invalid")
            except ValueError: raise
            except Exception: raise ValueError(f"{f['name']}_invalid")
    if kind=='deposit':
        # Deposit is a real form in the cabin workflow. The account number is
        # the canonical destination; legacy target/phone fields remain accepted
        # for backward compatibility with older requests.
        account=str(details.get('account_number','')).strip()
        if not account:
            raise ValueError('account_number_required')
    return details
MAX_IMAGE_BYTES=1_500_000
MAX_PRODUCT_IMAGES=1
IMAGE_DATA_PREFIX='data:image/'

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def db():
    DATA.mkdir(exist_ok=True); c=sqlite3.connect(DB,timeout=10); c.row_factory=sqlite3.Row; return c

def init():
    with LOCK,db() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS categories(id TEXT PRIMARY KEY,name TEXT NOT NULL UNIQUE COLLATE NOCASE,created_at TEXT);
        CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT,category TEXT,price INTEGER,available INTEGER,stock INTEGER,description TEXT,image_data TEXT,created_at TEXT,operation_kind TEXT);
        CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY,queue_number INTEGER UNIQUE,customer_name TEXT,customer_phone TEXT,items_json TEXT,total INTEGER,status TEXT,channel TEXT,created_at TEXT,updated_at TEXT);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id TEXT,event_type TEXT,payload_json TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS modules(id TEXT PRIMARY KEY,name TEXT,enabled INTEGER,config_json TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS highlights(id TEXT PRIMARY KEY,title TEXT,subtitle TEXT,description TEXT,kind TEXT,product_id TEXT,cta TEXT,active INTEGER,priority INTEGER,image_data TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS announcements(id TEXT PRIMARY KEY,title TEXT,message TEXT,type TEXT,active INTEGER,created_at TEXT);
        ''')
        # Lightweight migration for older MVP databases.
        for table, col in [('products','image_data TEXT'),('products','operation_kind TEXT'),('highlights','image_data TEXT')]:
            try: c.execute(f'ALTER TABLE {table} ADD COLUMN {col}')
            except sqlite3.OperationalError: pass
        # Categories are first-class admin data, while existing product categories are migrated automatically.
        existing_categories=c.execute("SELECT DISTINCT TRIM(category) AS name FROM products WHERE TRIM(category)<>''").fetchall()
        for row in existing_categories:
            c.execute('INSERT OR IGNORE INTO categories(id,name,created_at) VALUES(?,?,?)',('cat-'+uuid.uuid4().hex[:10],row['name'],now()))
        if c.execute('SELECT COUNT(*) n FROM products').fetchone()['n']==0:
            if CONFIG.get('enterprise',{}).get('sector')=='restaurant':
                rows=[
                  ('m101','Poulet braisé','Plats',3500,1,50,'Poulet braisé servi avec accompagnement.',None,now(),'menu_item'),
                  ('m102','Poisson braisé','Plats',4000,1,40,'Poisson braisé et accompagnement au choix.',None,now(),'menu_item'),
                  ('m103','Spaghetti viande','Plats',3000,1,30,'Spaghetti préparés avec sauce et viande.',None,now(),'menu_item'),
                  ('m104','Frites','Accompagnements',1000,1,80,'Portion de frites croustillantes.',None,now(),'menu_item'),
                  ('m105','Riz','Accompagnements',1000,1,80,'Portion de riz.',None,now(),'menu_item'),
                  ('m106','Jus naturel','Boissons',1500,1,60,'Jus naturel frais.',None,now(),'menu_item'),
                  ('m107','Eau','Boissons',500,1,100,'Bouteille d’eau.',None,now(),'menu_item'),
                  ('m108','Salade de fruits','Desserts',1500,1,40,'Dessert frais aux fruits.',None,now(),'menu_item')
                ]
                c.executemany('INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?,?)',rows)
            else:
                rows=[]
                for op in CONFIG['operation_catalog_data']['operations']:
                    rows.append((op['id'],op['name'],op['category'],0,1,999999,op['description'],None,now(),op['kind']))
                c.executemany('INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?,?)',rows)
        # Ensure seeded products also populate the category list on a fresh database.
        for row in c.execute("SELECT DISTINCT TRIM(category) AS name FROM products WHERE TRIM(category)<>''").fetchall():
            c.execute('INSERT OR IGNORE INTO categories(id,name,created_at) VALUES(?,?,?)',('cat-'+uuid.uuid4().hex[:10].upper(),row['name'],now()))
        if c.execute('SELECT COUNT(*) n FROM highlights').fetchone()['n']==0:
            if CONFIG.get('enterprise',{}).get('sector')=='restaurant':
                c.executemany('INSERT INTO highlights VALUES(?,?,?,?,?,?,?,?,?,?,?)', [
                    ('h101','Poulet braisé','Plat populaire','Un classique du restaurant.','product','m101','Commander',1,100,None,now()),
                    ('h102','Poisson braisé','Plat du moment','Savoureux et préparé à la demande.','product','m102','Commander',1,95,None,now()),
                    ('h103','Jus naturel','Boisson fraîche','Accompagnez votre repas avec un jus naturel.','product','m106','Commander',1,90,None,now())
                ])
            else:
                c.executemany('INSERT INTO highlights VALUES(?,?,?,?,?,?,?,?,?,?,?)', [])
        if c.execute('SELECT COUNT(*) n FROM announcements').fetchone()['n']==0:
            if CONFIG.get('enterprise',{}).get('sector')=='restaurant':
                c.execute('INSERT INTO announcements VALUES(?,?,?,?,?,?)',('a101','Bienvenue au restaurant NZELA','Choisissez vos plats, indiquez les quantités et envoyez votre commande.','info',1,now()))
            else:
                c.execute('INSERT INTO announcements VALUES(?,?,?,?,?,?)',('a001','Bienvenue à la cabine NZELA','Préparez vos opérations depuis votre téléphone.','info',1,now()))
        for mid in CONFIG.get('active_modules',[]):
            c.execute('INSERT OR REPLACE INTO modules(id,name,enabled,config_json,created_at) VALUES(?,?,?,?,COALESCE((SELECT created_at FROM modules WHERE id=?),?))',(mid,mid,1,json.dumps({'source':'enterprise.json'},ensure_ascii=False),mid,now()))

def ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:s.connect(('8.8.8.8',80)); return s.getsockname()[0]
    except OSError:return '127.0.0.1'
    finally:s.close()

def send(h,code,obj):
    b=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(code); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Cache-Control','no-store'); h.send_header('Access-Control-Allow-Origin','*'); h.send_header('Content-Length',str(len(b))); h.end_headers(); h.wfile.write(b)
def body(h):
    n=int(h.headers.get('Content-Length','0')); return json.loads(h.rfile.read(min(n,12_000_000)).decode() or '{}')
def payload(r):
    d=dict(r); d['items']=json.loads(d.pop('items_json')); return d
def event(c,rid,t,p={}): c.execute('INSERT INTO events(request_id,event_type,payload_json,created_at) VALUES(?,?,?,?)',(rid,t,json.dumps(p),now()))
def clean_image(value):
    if not value: return None
    values=value if isinstance(value,list) else [value]
    if len(values)>MAX_PRODUCT_IMAGES: raise ValueError('too_many_images')
    clean=[]
    for item in values:
        if not isinstance(item,str) or not item.startswith(IMAGE_DATA_PREFIX) or ',' not in item: raise ValueError('invalid_image')
        try: raw=base64.b64decode(item.split(',',1)[1],validate=True)
        except Exception: raise ValueError('invalid_image')
        if len(raw)>MAX_IMAGE_BYTES: raise ValueError('image_too_large')
        clean.append(item)
    return json.dumps(clean,ensure_ascii=False) if isinstance(value,list) else value


OPERATION_KINDS={'buy_credit','deposit','withdraw','transfer'}

class H(BaseHTTPRequestHandler):
    server_version=f'NZELA-Core/{VERSION}-MVP'
    def log_message(self,f,*a): print(f'[{now()}] {self.client_address[0]} {f%a}')
    def do_OPTIONS(self):
        self.send_response(204); self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,OPTIONS'); self.send_header('Access-Control-Allow-Headers','Content-Type'); self.end_headers()
    def do_GET(self):
        p=urlparse(self.path).path.rstrip('/') or '/'
        if p=='/api/health': return send(self,200,{'ok':True,'service':'NZELA CORE NETWORK','version':VERSION,'server_ip':ip(),'port':PORT,'time':now()})
        if p=='/api/identity':
            return send(self,200,{'identity':dict(CONFIG.get('identity',{}))})
        if p=='/api/config':
            public={k:v for k,v in CONFIG.items() if k!='operation_catalog_data'}
            public['operation_catalog']=CONFIG['operation_catalog_data']
            return send(self,200,public)
        if p=='/api/network': return send(self,200,{'server_ip':ip(),'port':PORT,'lan_url':f'http://{ip()}:{PORT}','hostname':socket.gethostname()})
        if p in ('/api/highlights','/api/admin/highlights'):
            q='SELECT * FROM highlights' + ('' if p.endswith('/admin/highlights') else ' WHERE active=1') + ' ORDER BY priority DESC,created_at DESC'
            with LOCK,db() as c:r=c.execute(q).fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p=='/api/categories':
            with LOCK,db() as c:r=c.execute('SELECT id,name,created_at FROM categories ORDER BY name COLLATE NOCASE').fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p=='/api/products':
            with LOCK,db() as c:r=c.execute('SELECT id,name,category,price,available,stock,description,image_data,created_at,operation_kind FROM products ORDER BY category COLLATE NOCASE,name COLLATE NOCASE').fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p in ('/api/announcements','/api/admin/announcements'):
            q='SELECT * FROM announcements' + ('' if p.endswith('/admin/announcements') else ' WHERE active=1') + ' ORDER BY created_at DESC'
            with LOCK,db() as c:r=c.execute(q).fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p=='/api/requests':
            with LOCK,db() as c:r=c.execute('SELECT * FROM requests ORDER BY queue_number DESC LIMIT 100').fetchall()
            return send(self,200,{'items':[payload(x) for x in r]})
        if p=='/api/modules':
            with LOCK,db() as c:r=c.execute('SELECT id,name,enabled,config_json,created_at FROM modules ORDER BY id').fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p=='/api/events':
            with LOCK,db() as c:r=c.execute('SELECT id,request_id,event_type,payload_json,created_at FROM events ORDER BY id DESC LIMIT 200').fetchall()
            return send(self,200,{'items':[dict(x) for x in r]})
        if p=='/api/stats':
            with LOCK,db() as c:
                counts={s:c.execute('SELECT COUNT(*) n FROM requests WHERE status=?',(s,)).fetchone()['n'] for s in STATUSES}; active=c.execute("SELECT COUNT(*) n FROM requests WHERE status IN('pending','preparing','ready')").fetchone()['n']
            return send(self,200,{'counts':counts,'active':active})
        if p.startswith('/api/requests/'):
            rid=p.split('/')[-1]
            with LOCK,db() as c:r=c.execute('SELECT * FROM requests WHERE id=?',(rid,)).fetchone()
            return send(self,200,payload(r)) if r else send(self,404,{'error':'request_not_found'})
        rel=p.lstrip('/') or 'index.html'; target=(WEB/rel).resolve()
        if not str(target).startswith(str(WEB.resolve())) or not target.is_file(): target=WEB/'index.html'
        try:
            b=target.read_bytes(); ct={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8'}.get(target.suffix,'application/octet-stream'); self.send_response(200); self.send_header('Content-Type',ct); self.send_header('Cache-Control','no-cache'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
        except OSError: send(self,404,{'error':'not_found'})
    def do_POST(self):
        p=urlparse(self.path).path.rstrip('/')
        try:d=body(self)
        except Exception:return send(self,400,{'error':'invalid_json'})
        if p=='/api/categories':
            name=str(d.get('name','')).strip()
            if not name or len(name)>80:return send(self,400,{'error':'invalid_category'})
            with LOCK,db() as c:
                try:
                    cid='cat-'+uuid.uuid4().hex[:10].upper(); c.execute('INSERT INTO categories(id,name,created_at) VALUES(?,?,?)',(cid,name,now())); c.commit()
                except sqlite3.IntegrityError:return send(self,409,{'error':'category_exists'})
            return send(self,201,{'id':cid,'name':name})
        if p=='/api/highlights':
            title=str(d.get('title','')).strip(); subtitle=str(d.get('subtitle','Nouveauté')).strip(); desc=str(d.get('description','')).strip(); kind=str(d.get('kind','service')).strip(); product_id=d.get('product_id'); cta=str(d.get('cta','Découvrir')).strip(); priority=int(d.get('priority',50))
            try:image=clean_image(d.get('image_data'))
            except ValueError as e:return send(self,400,{'error':str(e)})
            if not title:return send(self,400,{'error':'title_required'})
            hid='H-'+uuid.uuid4().hex[:8].upper()
            with LOCK,db() as c:c.execute('INSERT INTO highlights VALUES(?,?,?,?,?,?,?,?,?,?,?)',(hid,title,subtitle,desc,kind,product_id,cta,1,priority,image,now()));c.commit()
            return send(self,201,{'ok':True,'id':hid})
        if p=='/api/products':
            name=str(d.get('name','')).strip(); category=str(d.get('category','Général')).strip() or 'Général'; desc=str(d.get('description','')).strip(); price=int(d.get('price',0)); stock=int(d.get('stock',0)); available=1 if bool(d.get('available',stock>0)) else 0; operation_kind=str(d.get('operation_kind','')).strip()
            if len(category)>80:return send(self,400,{'error':'invalid_category'})
            try:image=clean_image(d.get('image_data'))
            except ValueError as e:return send(self,400,{'error':str(e)})
            if not name or price<0 or stock<0:return send(self,400,{'error':'invalid_product'})
            pid='p-'+uuid.uuid4().hex[:8]; t=now()
            with LOCK,db() as c:
                c.execute('INSERT OR IGNORE INTO categories(id,name,created_at) VALUES(?,?,?)',('cat-'+uuid.uuid4().hex[:10].upper(),category,t))
                c.execute('INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?,?)',(pid,name,category,price,available,stock,desc,image,t,operation_kind)); hid='H-'+uuid.uuid4().hex[:8].upper(); c.execute('INSERT INTO highlights VALUES(?,?,?,?,?,?,?,?,?,?,?)',(hid,name,'Nouveau produit',desc or 'Découvrez cette nouveauté.','product',pid,'Commander',1,100,image,t)); c.commit()
            return send(self,201,{'ok':True,'id':pid,'highlight_id':hid,'pinned':True})
        if p=='/api/announcements':
            title=str(d.get('title','')).strip(); message=str(d.get('message','')).strip(); typ=str(d.get('type','info')).strip()
            if not title or not message:return send(self,400,{'error':'title_and_message_required'})
            aid='A-'+uuid.uuid4().hex[:8].upper()
            with LOCK,db() as c:c.execute('INSERT INTO announcements VALUES(?,?,?,?,?,?)',(aid,title,message,typ,1,now()));c.commit()
            return send(self,201,{'ok':True,'id':aid})
        if p!='/api/requests':return send(self,404,{'error':'endpoint_not_found'})
        name=str(d.get('customer_name','')).strip(); phone=str(d.get('customer_phone','')).strip(); items=d.get('items',[])
        if not name or not isinstance(items,list) or not items:return send(self,400,{'error':'customer_name_and_items_required'})
        with LOCK,db() as c:
            total=0; norm=[]
            for it in items:
                pid=str(it.get('product_id','')).strip()
                try:
                    q=int(it.get('quantity',1))
                except (TypeError,ValueError):
                    return send(self,400,{'error':'invalid_quantity','service_id':pid})
                pdt=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                if not pdt:
                    return send(self,404,{'error':'product_not_found','service_id':pid})
                kind=str(it.get('kind') or pdt['operation_kind'] or '').strip().lower()
                # Product IDs point to catalogue articles; operation_kind is the stable business kind.
                if not kind:
                    kind=OPERATIONS_BY_ID.get(pid,{}).get('kind','')
                qmode=OPERATIONS.get(kind,{}).get('quantity_mode','single')
                if q<1 or (qmode!='multiple' and q!=1):
                    return send(self,400,{'error':'invalid_quantity','service_id':pid})
                if not pdt['available']:
                    return send(self,409,{'error':'service_unavailable','service_id':pid})
                if q > int(pdt['stock'] or 0):
                    return send(self,409,{'error':'insufficient_stock','service_id':pid,'available_stock':int(pdt['stock'] or 0)})
                try: details=validate_operation_config(kind,it.get('details',{}))
                except ValueError as e:return send(self,400,{'error':str(e),'service_id':pid})
                details['operation']=kind
                unit_price=int(pdt['price'] or 0); subtotal=unit_price*q; total+=subtotal
                norm.append({'product_id':pid,'name':pdt['name'],'quantity':q,'unit_price':unit_price,'subtotal':subtotal,'kind':kind,'details':details})
            qn=c.execute('SELECT COALESCE(MAX(queue_number),0)+1 n FROM requests').fetchone()['n']; rid='REQ-'+uuid.uuid4().hex[:8].upper();t=now();ch=str(d.get('channel','restaurant_web'))[:30]
            c.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?,?,?)',(rid,qn,name,phone,json.dumps(norm,ensure_ascii=False),total,'pending',ch,t,t))
            for item in norm:
                cur=c.execute('UPDATE products SET stock=stock-?, available=CASE WHEN stock-?<=0 THEN 0 ELSE available END WHERE id=? AND stock>=?',(item['quantity'],item['quantity'],item['product_id'],item['quantity']))
                if cur.rowcount!=1:
                    raise ValueError(f"insufficient_stock:{item['product_id']}")
            event(c,rid,'request_created',{'queue_number':qn,'channel':ch,'operation_count':len(norm),'total':total})
            c.commit()
        return send(self,201,{'ok':True,'request_id':rid,'queue_number':qn,'status':'pending','total':total,'operation_count':len(norm)})
    def do_DELETE(self):
        p=urlparse(self.path).path.rstrip('/')
        if p.startswith('/api/products/'):
            pid=p.split('/')[-1]
            with LOCK,db() as c:
                if not c.execute('SELECT 1 FROM products WHERE id=?',(pid,)).fetchone(): return send(self,404,{'error':'product_not_found'})
                c.execute('DELETE FROM products WHERE id=?',(pid,)); c.execute('DELETE FROM highlights WHERE product_id=?',(pid,)); c.commit()
            return send(self,200,{'ok':True,'id':pid})
        return send(self,404,{'error':'endpoint_not_found'})

    def do_PUT(self):
        p=urlparse(self.path).path.rstrip('/')
        if p=='/api/identity':
            try: d=body(self)
            except Exception: return send(self,400,{'error':'invalid_json'})
            identity=CONFIG.setdefault('identity',{})
            for key in ('name','slogan','logo_data','cover_data','description','phone','address','hours'):
                if key in d: identity[key]=str(d.get(key) or '')
            CONFIG_FILE.write_text(json.dumps({k:v for k,v in CONFIG.items() if k!='operation_catalog_data'},ensure_ascii=False,indent=2),encoding='utf-8')
            return send(self,200,{'ok':True,'identity':identity})
        if p.startswith('/api/products/'):
            pid=p.split('/')[-1]
            try:d=body(self)
            except Exception:return send(self,400,{'error':'invalid_json'})
            with LOCK,db() as c:
                old=c.execute('SELECT * FROM products WHERE id=?',(pid,)).fetchone()
                if not old:return send(self,404,{'error':'product_not_found'})
                try: price=int(d.get('price',old['price'])); stock=int(d.get('stock',old['stock']))
                except (TypeError,ValueError):return send(self,400,{'error':'invalid_product'})
                name=str(d.get('name',old['name'])).strip(); category=str(d.get('category',old['category'])).strip() or 'Général'; desc=str(d.get('description',old['description'] or '')).strip(); available=1 if bool(d.get('available',old['available'])) and stock>0 else 0
                if len(category)>80:return send(self,400,{'error':'invalid_category'})
                if not name or price<0 or stock<0:return send(self,400,{'error':'invalid_product'})
                try:image=clean_image(d.get('image_data',old['image_data']))
                except ValueError as e:return send(self,400,{'error':str(e)})
                c.execute('INSERT OR IGNORE INTO categories(id,name,created_at) VALUES(?,?,?)',('cat-'+uuid.uuid4().hex[:10].upper(),category,now()))
                c.execute('UPDATE products SET name=?,category=?,price=?,available=?,stock=?,description=?,image_data=? WHERE id=?',(name,category,price,available,stock,desc,image,pid)); c.commit()
            return send(self,200,{'ok':True,'id':pid})
        if p.startswith('/api/announcements/') and p.endswith('/active'):
            aid=p.split('/')[-2]
            try:active=1 if bool(body(self).get('active')) else 0
            except:return send(self,400,{'error':'invalid_json'})
            with LOCK,db() as c:
                r=c.execute('SELECT id FROM announcements WHERE id=?',(aid,)).fetchone()
                if not r:return send(self,404,{'error':'announcement_not_found'})
                c.execute('UPDATE announcements SET active=? WHERE id=?',(active,aid));c.commit()
            return send(self,200,{'ok':True,'id':aid,'active':active})
        if p.startswith('/api/highlights/') and p.endswith('/active'):
            hid=p.split('/')[-2]
            try:active=1 if bool(body(self).get('active')) else 0
            except:return send(self,400,{'error':'invalid_json'})
            with LOCK,db() as c:
                r=c.execute('SELECT id FROM highlights WHERE id=?',(hid,)).fetchone()
                if not r:return send(self,404,{'error':'highlight_not_found'})
                c.execute('UPDATE highlights SET active=? WHERE id=?',(active,hid));c.commit()
            return send(self,200,{'ok':True,'id':hid,'active':active})
        if not p.startswith('/api/requests/') or not p.endswith('/status'):return send(self,404,{'error':'endpoint_not_found'})
        rid=p.split('/')[-2]
        try:status=str(body(self).get('status','')).strip()
        except:return send(self,400,{'error':'invalid_json'})
        if status not in STATUSES:return send(self,400,{'error':'invalid_status','allowed':STATUSES})
        with LOCK,db() as c:
            r=c.execute('SELECT * FROM requests WHERE id=?',(rid,)).fetchone()
            if not r:return send(self,404,{'error':'request_not_found'})
            old=r['status']; c.execute('UPDATE requests SET status=?,updated_at=? WHERE id=?',(status,now(),rid)); event(c,rid,'status_changed',{'from':old,'to':status}); c.commit(); r=c.execute('SELECT * FROM requests WHERE id=?',(rid,)).fetchone()
        return send(self,200,payload(r))

def main():
    init(); s=ThreadingHTTPServer((HOST,PORT),H); print(f'\nNZELA CORE NETWORK — MVP {VERSION}'); print(f'Local: http://127.0.0.1:{PORT}'); print(f'LAN  : http://{ip()}:{PORT}\nCTRL+C pour arrêter\n'); s.serve_forever()
if __name__=='__main__': main()
