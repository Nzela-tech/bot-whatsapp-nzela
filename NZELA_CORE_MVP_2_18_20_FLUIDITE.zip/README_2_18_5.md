# NZELA CORE 2.18.5 — audit fixes

Base: 2.18.4. No client behavior was changed.

Fixes:
- admin template section nesting corrected;
- admin theme controls aligned with the client: one light/dark button + 0–100% theme scale;
- removed contradictory admin dark-only theme/scale CSS;
- admin theme and scale use the same localStorage keys and CSS variable as the client;
- admin layout no longer changes between light and dark;
- version metadata aligned to 2.18.5 and server health/startup use VERSION.
