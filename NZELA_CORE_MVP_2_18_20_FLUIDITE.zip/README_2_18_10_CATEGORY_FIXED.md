# NZELA CORE MVP 2.18.11 — Sélecteur de catégorie accessible au défilement

## Correctif
Le sélecteur de catégorie du catalogue reste accessible pendant le défilement de la liste des produits.

### Comportement
- Le client peut faire défiler une catégorie contenant beaucoup de produits.
- Le sélecteur `#cat` reste visible dans la zone supérieure de l'écran.
- Le changement de catégorie reste immédiat et bénéficie du rafraîchissement automatique de 2.18.8.
- Le sélecteur reste limité à la section catalogue et ne flotte pas sur les autres pages.
- Le positionnement est adapté aux écrans mobiles.

## Principe
On ne demande plus au client de remonter toute la page pour changer de catégorie. L'accès au filtre suit l'utilisateur pendant la consultation du catalogue.
