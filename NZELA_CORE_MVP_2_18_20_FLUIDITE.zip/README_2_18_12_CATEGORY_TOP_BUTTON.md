# NZELA CORE MVP 2.18.12 — Catégorie + retour en haut

## Modifications client

- Le sélecteur de catégories est remis à son emplacement naturel dans l'en-tête du catalogue.
- Suppression du comportement `position: fixed` ajouté en 2.18.10.
- Ajout d'un seul bouton `↑` à côté de l'icône flottante de la boutique.
- Le bouton `↑` ramène doucement le client en haut de la page, quelle que soit sa position dans le catalogue.
- Le rafraîchissement automatique et le filtrage immédiat de 2.18.8 sont conservés.
- La fiche produit et sa photo de 2.18.11 sont conservées.

## Vérifications

- Python compile OK
- JavaScript syntax check OK
- JSON parse OK
