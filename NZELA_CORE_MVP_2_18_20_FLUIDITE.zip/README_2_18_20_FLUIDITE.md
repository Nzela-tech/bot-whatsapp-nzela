# NZELA CORE 2.18.20 — Fluidité

Amélioration ciblée de la fluidité sans refonte du design.

## Changements

- Le filtre/recherche catalogue est regroupé sur le prochain frame navigateur (`requestAnimationFrame`) pour éviter des rendus successifs pendant une frappe rapide.
- Les boutons du catalogue utilisent désormais une délégation d'événements : les handlers ne sont plus recréés après chaque rendu.
- Les actions des highlights utilisent également la délégation d'événements.
- L'historique recharge les commandes en parallèle au lieu d'attendre chaque requête l'une après l'autre.
- Suppression d'une écriture `localStorage` dupliquée lors du déplacement de l'identité boutique.
- Aucun changement volontaire du design, du thème ou du comportement métier.
