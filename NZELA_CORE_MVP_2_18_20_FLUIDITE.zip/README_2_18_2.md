# NZELA CORE MVP 2.18.2

## Ajout
- Le point flottant d'identité boutique côté client est déplaçable à la souris ou au doigt.
- Le point flottant d'identité boutique côté admin est également déplaçable.
- La position est mémorisée localement dans le navigateur.
- Un simple clic ouvre toujours la fiche boutique.
- Le déplacement ne modifie pas la mise en page et ne déplace pas la barre principale.
