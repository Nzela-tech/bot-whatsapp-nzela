# NZELA CORE MVP 2.14.0 — Formulaires déroulants

## Modification

Les deux formulaires administrateur sont maintenant fermés par défaut :

- Restaurant : le formulaire apparaît après clic sur « Modifier les informations » ou « Compléter les informations ».
- Produits : le formulaire apparaît après clic sur « Ajouter un produit ».
- Annuler referme le formulaire.
- Enregistrer referme le formulaire après succès.
- L'ouverture du formulaire Restaurant fait défiler la page doucement vers le formulaire.
- Les formulaires ne sont plus affichés en permanence.

## Fichiers modifiés

- `web/assets/admin.js`
- `web/assets/admin.css`
- `VERSION`

## Test

Ouvrir l'espace administrateur puis vérifier :
1. Onglet Restaurant : aucun formulaire visible au chargement.
2. Cliquer sur Modifier les informations.
3. Vérifier le défilement et l'apparition du formulaire.
4. Cliquer sur Annuler.
5. Onglet Produits : aucun formulaire visible au chargement.
6. Cliquer sur Ajouter un produit.
7. Vérifier l'apparition du formulaire puis Annuler.
