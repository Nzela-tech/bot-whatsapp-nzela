import json
import urllib.request

BASE = 'http://127.0.0.1:8787'

def api(path, method='GET', payload=None):
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
    req = urllib.request.Request(BASE + path, data=data, method=method)
    if data is not None:
        req.add_header('Content-Type', 'application/json')
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read())

health = api('/api/health')
assert health['ok']
products = api('/api/products')['items']
product = next(x for x in products if x['operation_kind'] == 'menu_item')

order = api('/api/requests', 'POST', {
    'customer_name': 'MVP TEST',
    'customer_phone': '000000000',
    'items': [{'product_id': product['id'], 'quantity': 1, 'kind': 'menu_item', 'details': {}}]
})
assert order['ok'] and order['status'] == 'pending'

updated = api('/api/requests/' + order['request_id'] + '/status', 'PUT', {'status': 'preparing'})
assert updated['status'] == 'preparing'

stored = api('/api/requests/' + order['request_id'])
assert stored['id'] == order['request_id']
assert stored['items'][0]['product_id'] == product['id']

print('MVP END-TO-END TEST OK')
print(f"Commande #{order['queue_number']:03d} | {order['total']} FCFA | preparing")
