import json,urllib.request
B='http://127.0.0.1:8787'
def g(p):
 with urllib.request.urlopen(B+p,timeout=3) as r:return json.loads(r.read())
assert g('/api/health')['ok']; assert len(g('/api/products')['items'])>=1; assert g('/api/network')['port']==8787
print('SMOKE TEST OK')
