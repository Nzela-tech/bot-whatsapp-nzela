# NZELA CORE MVP 2.18.3

## Correction d'affichage
- Suppression des anciens décalages/paddings réservés sous la barre fixe.
- Suppression des marges négatives et règles résiduelles de l'ancien dock.
- La barre principale reste fixe en haut sans laisser une zone bloquée dessous.
- Le point flottant est conservé, mais reste hors du flux de mise en page.
