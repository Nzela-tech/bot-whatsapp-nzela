# NZELA 2.13.0 — Logo restaurant uniquement

- L’identité du restaurant utilise uniquement son logo.
- La photo de couverture du restaurant a été retirée de l’interface.
- Le logo est affiché dans une forme ronde, avec `object-fit: contain`.
- Le logo reste facultatif.
- L’espace administrateur conserve son mode sombre et son scale.
