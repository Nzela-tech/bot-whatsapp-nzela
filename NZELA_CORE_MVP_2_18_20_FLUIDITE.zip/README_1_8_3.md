# NZELA CORE 1.8.3

## Correction cabine — Envoi d'argent

Cette version améliore uniquement le parcours spécifique à l'opération `transfer` du module `credit_cabine`.

- La carte d'ouverture contient uniquement le formulaire.
- Formulaire centré, compact et responsive.
- Champs : numéro de téléphone, nom du destinataire, montant (FCFA).
- Aucun CNI / identifiant demandé pour cette opération.
- La demande est envoyée directement au serveur au clic sur « Envoyer la demande ».
- Après succès, elle est enregistrée dans SQLite et devient visible automatiquement dans le tableau de bord administrateur par synchronisation.
- Le transfert direct est retiré du panier après enregistrement pour éviter une double soumission.
- L'administrateur affiche aussi clairement le nom du destinataire.

La règle est spécifique au module `credit_cabine` et ne modifie pas le moteur universel.
