# NZELA CORE MVP 2.18.17 — Suppression des étoiles

- Suppression des glyphes décoratifs en forme d’étoile dans l’interface client et les libellés d’opérations.
- Remplacement par un symbole neutre `•` lorsqu’un caractère de secours est nécessaire.
- Aucun changement de fonctionnement.
