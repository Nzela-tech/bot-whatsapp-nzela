# NZELA CORE 2.18.19 — Audit fixes

Cette version part de 2.18.18 et applique uniquement les corrections techniques demandées, sans refonte visuelle.

## 1. Stock après commande
- Le stock est décrémenté au moment de la création de la commande.
- La décrémentation est protégée par une condition `stock >= quantité`.
- Le produit devient automatiquement indisponible lorsque son stock atteint 0.
- Une modification admin avec stock à 0 force également `available=false`.

## 2. Images
- Une seule limite serveur commune : 1,5 Mo de données décodées.
- L'interface admin produit et logo utilise la même limite de 1,5 Mo.
- Le serveur vérifie explicitement le format data-image et la présence du séparateur base64.
- Un produit reste limité à une image.

## 3. Nettoyage progressif CSS/JS
- Suppression de règles CSS de prévisualisation clairement supersédées par les versions finales 2.18.16/2.18.18.
- Suppression de quelques styles de barre/outils qui ne correspondent plus au HTML actuel.
- Aucun changement volontaire de structure ou de design de la carte actuelle.

## Vérifications
- Python syntax OK
- JavaScript syntax OK
- JSON OK
- tests smoke/MVP
- test de commande avec décrémentation du stock
- test passage du stock à zéro → produit indisponible
- ZIP integrity OK
