@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo       NZELA CORE 1.9.1 - MVP TEST
echo ============================================
py -3 tests\mvp_test.py
if errorlevel 1 (
  echo.
  echo Le serveur NZELA doit etre lance avec start_nzela.bat
  pause
  exit /b 1
)
echo.
pause
